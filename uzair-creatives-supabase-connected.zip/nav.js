/* Uzair Creatives - mobile menu + dropdown sub-menus (shared by every page) */
(() => {
  const $ = (s, c = document) => c.querySelector(s), $$ = (s, c = document) => [...c.querySelectorAll(s)];
  const mb = $(".menu-btn"), nav = $("#nav");
  if (!mb || !nav) return;
  const closeDD = except => $$(".dd.open").forEach(d => { if (d !== except) { d.classList.remove("open"); $(".dd-btn", d).setAttribute("aria-expanded", "false"); } });
  mb.addEventListener("click", () => {
    const o = nav.classList.toggle("open");
    mb.setAttribute("aria-expanded", o); mb.setAttribute("aria-label", o ? "Close menu" : "Open menu");
  });
  $$("a", nav).forEach(a => a.addEventListener("click", () => {
    nav.classList.remove("open"); mb.setAttribute("aria-expanded", "false"); mb.setAttribute("aria-label", "Open menu"); closeDD();
  }));
  $$(".dd-btn", nav).forEach(b => b.addEventListener("click", e => {
    e.stopPropagation();
    const d = b.parentElement, o = !d.classList.contains("open");
    closeDD(d); d.classList.toggle("open", o); b.setAttribute("aria-expanded", String(o));
  }));
  document.addEventListener("click", e => { if (!e.target.closest(".dd")) closeDD(); });
  document.addEventListener("keydown", e => { if (e.key === "Escape") closeDD(); });
})();
