/* Uzair Creatives v5 - light scroll engine.
   Native scrolling (no scroll hijack). Cards enter via CSS scroll-driven animations (see scrollfx.css).
   JS only does: hero scene (6 elements), 3 project cards, background tint, pause-when-hidden. All positions are cached. */
(() => {
  const $ = (s, c = document) => c.querySelector(s), $$ = (s, c = document) => [...c.querySelectorAll(s)];
  const clamp = (v, a = 0, b = 1) => v < a ? a : v > b ? b : v;
  const root = document.documentElement;
  if (matchMedia("(prefers-reduced-motion: reduce)").matches) { root.classList.add("rm"); return; }
  const lite = root.classList.contains("lite");

  const secs = $$(".section"), proj = $("#portfolio"), track = $("#projects"), cam = $(".bg-cam"), move = $(".bg-move");
  const hbar = document.createElement("div"); hbar.className = "hbar"; hbar.innerHTML = "<i></i>"; const hfill = hbar.firstChild;

  /* floating glass shapes (animated by CSS only, none on weak devices) */
  if (!lite) secs.forEach((s, i) => {
    if (s.id === "portfolio") return;
    const side = i % 2 ? "left" : "right";
    ["ring", "orb", "sq"].forEach((k, j) => {
      const d = document.createElement("i"); d.className = "deco " + k; d.setAttribute("aria-hidden", "true");
      d.style[j === 1 ? (side === "left" ? "right" : "left") : side] = (-4 + j * 3) + "%"; d.style.top = (8 + j * 30) + "%"; s.prepend(d);
    });
  });

  /* ---- cached geometry ---- */
  let vh = innerHeight, vw = innerWidth, docMax = 1, pinTop = 0, pinH = 1, pinMax = 0, cards = [];
  function pinSetup() {
    if (!proj || !track) return;
    proj.classList.add("pinned");
    const max = track.scrollWidth - track.clientWidth;
    if (max > 40) { pinMax = max; proj.style.height = Math.round(innerHeight + max * 1.15) + "px"; if (!hbar.isConnected) track.after(hbar); }
    else { pinMax = 0; proj.classList.remove("pinned"); proj.style.height = ""; hbar.remove(); }
  }
  function measure() {
    vh = innerHeight; vw = innerWidth; const y = scrollY;
    pinSetup();
    docMax = Math.max(1, document.documentElement.scrollHeight - vh);
    if (proj) { const r = proj.getBoundingClientRect(); pinTop = r.top + y; pinH = Math.max(1, proj.offsetHeight - vh); }
    cards = $$(".proj", track || document).map(c => ({ el: c, cx: c.offsetLeft - track.offsetLeft + c.offsetWidth / 2 }));
    dispatchEvent(new Event("uc:layout"));
    camTarget(); camStep(true); update(true);
  }

  /* ---- background camera: scroll position -> where the photo looks (focus x, y, zoom). One transform, eased. ---- */
  const WP = [[0, .58, .50, 1.05], [.12, .64, .50, 1.18], [.27, .566, .50, 1.28], [.45, .84, .52, 1.25], [.62, .28, .38, 1.32], [.80, .10, .55, 1.24], [1, .5, .5, 1.08]];
  let tgt = [.58, .5, 1.1], cur = [.58, .5, 1.1], camRun = false, heroMode = true;
  const ease = t => t * t * (3 - 2 * t);
  function camTarget() {
    const p = clamp(scrollY / docMax);
    let i = 0; while (i < WP.length - 2 && p > WP[i + 1][0]) i++;
    const a = WP[i], b = WP[i + 1], t = ease(clamp((p - a[0]) / (b[0] - a[0])));
    tgt = [a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t, a[3] + (b[3] - a[3]) * t];
    const hm = scrollY < vh * .55; if (hm !== heroMode) { heroMode = hm; cam.classList.toggle("hero-mode", hm); }
    if (!camRun) { camRun = true; requestAnimationFrame(() => camStep(false)); }
  }
  function camStep(snap) {
    const k = snap ? 1 : .14; let moving = false;
    for (let n = 0; n < 3; n++) { const d = tgt[n] - cur[n]; cur[n] += d * k; if (Math.abs(d) > (n < 2 ? .0004 : .0008)) moving = true; }
    const W = Math.max(vw, vh * 16 / 9), H = W * 9 / 16, s = vw < 700 ? 1 + (cur[2] - 1) * .6 : cur[2];
    let tx = -(cur[0] - .5) * W * s, ty = -(cur[1] - .5) * H * s;
    const mx = Math.max(0, (W * s - vw) / 2), my = Math.max(0, (H * s - vh) / 2); tx = clamp(tx, -mx, mx); ty = clamp(ty, -my, my);
    move.style.transform = "translate3d(" + tx.toFixed(1) + "px," + ty.toFixed(1) + "px,0) scale(" + s.toFixed(4) + ")";
    if (moving && !snap) requestAnimationFrame(() => camStep(false)); else camRun = false;
  }

  /* ---- per-frame work (projects only; the camera has its own eased loop) ---- */
  let busy = false, lastHp = -1;
  const queue = () => { camTarget(); if (!busy) { busy = true; requestAnimationFrame(() => update(false)); } };
  function update(force) {
    busy = false; const y = scrollY;

    projTarget(force);
  }
  /* projects: eased horizontal travel + soft arc, transforms only */
  let pTgt = 0, pCur = 0, pRun = false;
  function projTarget(snap) {
    if (!pinMax || !cards.length) return;
    pTgt = clamp((scrollY - pinTop) / pinH); if (snap) pCur = pTgt;
    if (!pRun) { pRun = true; requestAnimationFrame(projStep); }
  }
  function projStep() {
    const d = pTgt - pCur; pCur += d * .22; const done = Math.abs(d) < .0004; if (done) pCur = pTgt;
    const tx = -pCur * pinMax; hfill.style.transform = "scaleX(" + pCur.toFixed(3) + ")";
    const n = cards.length, ent = clamp((scrollY - (pinTop - vh * .95)) / (vh * .8));
    cards.forEach((c, i) => {
      const x = clamp((c.cx + tx - vw / 2) / (vw / 2), -1.4, 1.4), a = Math.abs(x);
      const t = clamp(ent * (n * .5 + 1) - i * .5), e = t * t * (3 - 2 * t);
      c.el.style.translate = tx.toFixed(1) + "px " + ((1 - e) * 70 + a * 10).toFixed(1) + "px";
      c.el.style.setProperty("--o", ((1 - clamp((a - .8) / .7) * .6) * e).toFixed(3));
    });
    if (done) pRun = false; else requestAnimationFrame(projStep);
  }
  addEventListener("scroll", queue, { passive: true });

  const terms = $("#terms");
  if (terms && window.IntersectionObserver) new IntersectionObserver(es => terms.classList.toggle("live", es[0].isIntersecting), { rootMargin: "120px" }).observe(terms);

  /* re-measure only when layout really changes */
  let mt; const remeasure = () => { clearTimeout(mt); mt = setTimeout(measure, 120); };
  addEventListener("resize", remeasure); addEventListener("load", measure);
  if (window.ResizeObserver) { let lastH = document.body.scrollHeight; new ResizeObserver(() => { const h = document.body.scrollHeight; if (Math.abs(h - lastH) > 4) { lastH = h; remeasure(); } }).observe(document.body); }
  if (track) new MutationObserver(remeasure).observe(track, { childList: true });
  measure();
})();
