/* Uzair Creatives - blog page extras: WhatsApp button, year, scroll progress, card spotlight */
(() => {
  const $ = s => document.querySelector(s);
  const num = String(CONFIG.whatsappNumber).replace(/\D/g, ""), ok = /^\d{10,15}$/.test(num);
  const wa = $("#wa");
  wa.href = "https://wa.me/" + (ok ? num : "YOURWHATSAPPNUMBER") + "?text=" + encodeURIComponent(CONFIG.whatsappMessage);
  $("#year").textContent = new Date().getFullYear();
  const bar = $("#progress"); let t = false;
  const upd = () => { const h = document.documentElement; bar.style.transform = "scaleX(" + (h.scrollTop / ((h.scrollHeight - h.clientHeight) || 1)) + ")"; t = false; };
  addEventListener("scroll", () => { if (!t) { t = true; requestAnimationFrame(upd); } }, { passive: true }); upd();
  if (matchMedia("(hover:hover)").matches) document.addEventListener("pointermove", e => {
    const c = e.target.closest && e.target.closest(".card"); if (!c) return;
    const r = c.getBoundingClientRect(); c.style.setProperty("--mx", e.clientX - r.left + "px"); c.style.setProperty("--my", e.clientY - r.top + "px");
  }, { passive: true });
})();
