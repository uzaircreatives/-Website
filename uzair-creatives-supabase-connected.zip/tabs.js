/* Uzair Creatives - Contact section tabs: "Project Inquiry" and "Book a Free Slot" */
(() => {
  const $ = (s, c = document) => c.querySelector(s), $$ = (s, c = document) => [...c.querySelectorAll(s)];
  const box = $("#contact"); if (!box) return;
  const tabs = $$('[role="tab"]', box), panels = { inquiry: $("#panel-inquiry"), book: $("#book") };
  const reduce = matchMedia("(prefers-reduced-motion: reduce)");
  function show(name) {
    tabs.forEach(t => { const on = t.dataset.tab === name; t.setAttribute("aria-selected", String(on)); t.tabIndex = on ? 0 : -1; });
    Object.entries(panels).forEach(([k, p]) => { p.hidden = k !== name; if (k === name) $$("[data-r]", p).forEach(x => x.classList.add("in")); });
  }
  const toContact = () => box.scrollIntoView({ behavior: reduce.matches ? "auto" : "smooth", block: "start" });
  tabs.forEach((t, i) => {
    t.addEventListener("click", () => show(t.dataset.tab));
    t.addEventListener("keydown", e => {
      if (e.key !== "ArrowRight" && e.key !== "ArrowLeft") return;
      const n = tabs[(i + (e.key === "ArrowRight" ? 1 : tabs.length - 1)) % tabs.length]; n.focus(); show(n.dataset.tab);
    });
  });
  document.addEventListener("click", e => {
    const a = e.target.closest && e.target.closest('a[href="#book"], a[href="#contact"]'); if (!a) return;
    const name = a.getAttribute("href") === "#book" ? "book" : "inquiry";
    e.preventDefault(); show(name); history.pushState(null, "", "#" + (name === "book" ? "book" : "contact")); toContact();
  });
  addEventListener("hashchange", () => { if (location.hash === "#book") { show("book"); toContact(); } else if (location.hash === "#contact") show("inquiry"); });
  if (location.hash === "#book") { show("book"); setTimeout(toContact, 60); }
})();
