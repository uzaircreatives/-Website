(() => {
  const root = document.documentElement;
  /* spotlight follows the pointer on every card (one rAF-throttled handler) */
  let f = 0, ev;
  addEventListener("pointermove", e => { ev = e; if (f) return; f = requestAnimationFrame(() => { f = 0; const c = ev.target.closest && ev.target.closest(".card,.faq,form,.stats>div"); if (c) { const r = c.getBoundingClientRect(); c.style.setProperty("--mx", ev.clientX - r.left + "px"); c.style.setProperty("--my", ev.clientY - r.top + "px"); } }); }, { passive: true });

  /* depth parallax + scroll-velocity (one loop, sleeps when still) + section mood tint */
  const cam = document.querySelector(".bg-cam");
  if (cam && !matchMedia("(prefers-reduced-motion: reduce)").matches) {
    const fine = matchMedia("(hover:hover) and (pointer:fine)").matches;
    let bx = 0, by = 0, tx = 0, ty = 0, vel = 0, last = scrollY, on = false;
    const loop = () => {
      vel = Math.min(1, Math.abs(scrollY - last) / 70) * .35 + vel * .65; last = scrollY; bx += (tx - bx) * .06; by += (ty - by) * .06;
      cam.style.setProperty("--bx", bx.toFixed(3)); cam.style.setProperty("--by", by.toFixed(3)); cam.style.setProperty("--vel", vel.toFixed(3));
      if (Math.abs(tx - bx) + Math.abs(ty - by) > .002 || vel > .01) requestAnimationFrame(loop); else on = false;
    };
    const wake = () => { if (!on) { on = true; requestAnimationFrame(loop); } };
    if (fine) addEventListener("pointermove", e => { tx = e.clientX / innerWidth - .5; ty = e.clientY / innerHeight - .5; wake(); }, { passive: true });
    addEventListener("scroll", wake, { passive: true });
    const mood = document.createElement("i"); mood.className = "mood"; cam.insertBefore(mood, cam.querySelector(".fog"));
    const C = { services: "40,150,255,.10", lab: "130,90,255,.13", portfolio: "30,120,255,.10", "how-it-works": "0,190,200,.10", method: "90,100,255,.12", terms: "120,90,255,.12", about: "40,170,255,.10", faq: "140,90,255,.11", contact: "0,180,210,.11", reviews: "50,120,255,.11" };
    if (window.IntersectionObserver) { const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) mood.style.backgroundColor = C[e.target.id] ? "rgba(" + C[e.target.id] + ")" : "transparent"; }), { rootMargin: "-45% 0px -45% 0px" }); document.querySelectorAll(".section").forEach(s => io.observe(s)); }
  }

  /* inertia scroll: desktop mouse/trackpad only, touch keeps native momentum */
  if (matchMedia("(prefers-reduced-motion: reduce)").matches || !matchMedia("(hover:hover) and (pointer:fine)").matches) return;
  let cur = scrollY, tgt = scrollY, run = false;
  const max = () => root.scrollHeight - innerHeight, clamp = v => Math.max(0, Math.min(max(), v));
  const step = () => { const d = tgt - cur; cur += d * .1; if (Math.abs(d) < .5) { cur = tgt; run = false; } scrollTo({ top: cur, behavior: "instant" }); if (run) requestAnimationFrame(step); };
  const go = y => { tgt = clamp(y); if (!run) { cur = scrollY; run = true; requestAnimationFrame(step); } };
  addEventListener("wheel", e => {
    if (e.ctrlKey || Math.abs(e.deltaX) > Math.abs(e.deltaY) || document.querySelector("dialog[open]") || (e.target.closest && e.target.closest("textarea,select"))) return;
    e.preventDefault(); go((run ? tgt : scrollY) + e.deltaY * (e.deltaMode === 1 ? 33 : 1));
  }, { passive: false });
  addEventListener("scroll", () => { if (!run) cur = tgt = scrollY; }, { passive: true });
  document.addEventListener("click", e => {
    const a = e.target.closest && e.target.closest('a[href^="#"]'); if (!a || a.getAttribute("href").length < 2) return;
    const el = document.querySelector(a.getAttribute("href")); if (!el) return;
    e.preventDefault(); history.pushState(null, "", a.getAttribute("href"));
    go(el.getBoundingClientRect().top + scrollY - (parseFloat(getComputedStyle(el).scrollMarginTop) || 0));
  });
})();
