/* Uzair Creatives - booking, reviews, counters and interactive touches.
   Edit the two settings below. Everything else works automatically. */

/* ===== SETTINGS ===== */
const BOOKING = {
  slots: ["11:00 AM", "1:00 PM", "3:00 PM", "5:00 PM", "8:00 PM"], // times shown to visitors (Pakistan time)
  closedWeekdays: [],   // days you are NOT available. 0 = Sunday, 1 = Monday ... 6 = Saturday. Example: [0] closes Sundays
  daysAhead: 30         // how many days ahead people can book
};

/* Instant first message after someone sends an inquiry or books a slot.
   1) A "Message me on WhatsApp" button always appears after sending (uses your whatsappNumber from script.js).
   2) Optional automatic email/WhatsApp from you: paste a Make or n8n webhook URL here. The website sends the form data
      to it right after a successful submit, and your workflow sends the first message. Leave "" to turn this off. */
const AUTOMATION = { webhookUrl: "" };

/* Supabase public frontend configuration. The publishable key is intended for browser use.
   Public review submissions are displayed to all visitors. Add anti-spam protection if needed. */
const SUPABASE_URL = "https://qldudhdwlidpqcvgotft.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_CXueqWzXDWeRQynZDBfxog_ZXzc8cf7";
const REVIEWS = [];

(() => {
  const $ = (s, c = document) => c.querySelector(s), $$ = (s, c = document) => [...c.querySelectorAll(s)];
  const reduce = matchMedia("(prefers-reduced-motion: reduce)");


  /* ----- instant first message: WhatsApp button + optional webhook ----- */
  const waNum = () => String(typeof CONFIG !== "undefined" ? CONFIG.whatsappNumber : "").replace(/\D/g, "");
  const niceDate = v => { const d = new Date(v + "T00:00:00"); return isNaN(d) ? v : d.toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short" }); };
  function clearNext(status) { const n = status.parentElement.querySelector(".next-step"); if (n) n.remove(); }
  function afterSuccess(kind, d, status) {
    if (AUTOMATION.webhookUrl) {
      const p = new URLSearchParams({ kind, page: location.href, sent_at: new Date().toISOString() });
      Object.entries(d).forEach(([k, v]) => { if (k !== "bot-field" && k !== "form-name") p.set(k, v); });
      fetch(AUTOMATION.webhookUrl, { method: "POST", mode: "no-cors", keepalive: true, headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: p.toString() }).catch(() => {});
    }
    const num = waNum(); if (!/^\d{8,15}$/.test(num)) return;
    const text = kind === "booking"
      ? "Hi Uzair, I just requested a slot on " + niceDate(d.date) + " at " + d.slot + ". My name is " + d.name + "."
      : "Hi Uzair, I just sent a project inquiry on your website about " + (d.service || "a project") + ". My name is " + d.name + ".";
    clearNext(status);
    const box = document.createElement("div"); box.className = "next-step";
    const p = document.createElement("p"); p.textContent = "Want a faster reply? Send me a quick WhatsApp message.";
    const a = document.createElement("a"); a.className = "btn btn-outline"; a.target = "_blank"; a.rel = "noopener"; a.href = "https://wa.me/" + num + "?text=" + encodeURIComponent(text); a.textContent = "Message me on WhatsApp";
    box.append(p, a); status.after(box);
  }

  /* ----- shared form sender (same method as the contact form, works with Netlify Forms) ----- */
  function bind(form, status, ok, fail, extraCheck, kind) {
    form.addEventListener("submit", async e => {
      e.preventDefault();
      if (!form.checkValidity()) { form.reportValidity(); return; }
      if (extraCheck) { const msg = extraCheck(); if (msg) { status.className = "err"; status.textContent = msg; return; } }
      const btn = form.querySelector("button[type=submit]"); btn.disabled = true; status.className = ""; status.textContent = "Sending..."; clearNext(status); const data = Object.fromEntries(new FormData(form));
      try {
        const r = await fetch("/__forms.html", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams(new FormData(form)).toString() });
        if (!r.ok) throw new Error(r.status);
        form.reset(); form.dispatchEvent(new Event("reset")); status.className = "ok"; status.textContent = ok; if (kind) afterSuccess(kind, data, status);
      } catch (err) { status.className = "err"; status.textContent = fail; }
      btn.disabled = false;
    });
  }


  /* contact form is sent by script.js; watch it so the same first message appears after a successful send */
  const cf = $("#inquiry"), cs = $("#status");
  if (cf && cs) {
    let held = null;
    cf.addEventListener("submit", () => { if (cf.checkValidity()) { held = Object.fromEntries(new FormData(cf)); clearNext(cs); } });
    new MutationObserver(() => { if (cs.className === "ok" && held) { const d = held; held = null; afterSuccess("inquiry", d, cs); } else if (cs.className === "err") held = null; }).observe(cs, { attributes: true, attributeFilter: ["class"] });
  }

  /* ----- booking ----- */
  const bf = $("#booking");
  if (bf) {
    const date = $("#b-date"), slotBox = $("#slots"), slotInput = $("#b-slot"), bs = $("#b-status");
    const iso = d => new Date(d.getTime() - d.getTimezoneOffset() * 6e4).toISOString().slice(0, 10);
    const t = new Date(); t.setDate(t.getDate() + 1); date.min = iso(t);
    const m = new Date(); m.setDate(m.getDate() + BOOKING.daysAhead); date.max = iso(m);
    const pick = btn => { $$(".slot", slotBox).forEach(b => b.setAttribute("aria-checked", String(b === btn))); slotInput.value = btn ? btn.dataset.v : ""; };
    BOOKING.slots.forEach(v => {
      const b = document.createElement("button"); b.type = "button"; b.className = "slot"; b.setAttribute("role", "radio"); b.setAttribute("aria-checked", "false"); b.dataset.v = v + " PKT"; b.textContent = v;
      b.addEventListener("click", () => pick(b)); slotBox.appendChild(b);
    });
    bf.addEventListener("reset", () => pick(null));
    bind(bf, bs, "Slot request sent! I will confirm it on WhatsApp or email soon.", "Sorry, your request could not be sent. Please try again, or message me on WhatsApp.", () => {
      if (!slotInput.value) return "Please choose a time slot.";
      const d = new Date(date.value + "T00:00:00");
      if (BOOKING.closedWeekdays.includes(d.getDay())) return "I am not available on that day. Please choose another date.";
      return "";
    }, "booking");
  }

  /* ----- shared reviews database (Supabase) ----- */
  const list = $("#review-list");
  if (list) {
    const rf = $("#review-form");
    const status = $("#r-status");
    const emptyMessage = "No reviews yet. If we have worked together, I would love to hear your feedback.";
    function showEmpty() {
      if (!list.children.length) {
        const p = document.createElement("p");
        p.className = "review-empty";
        p.textContent = emptyMessage;
        list.appendChild(p);
      }
    }
    function addReview(r, prepend = false) {
      const empty = list.querySelector(".review-empty");
      if (empty) empty.remove();
      const c = document.createElement("article"); c.className = "card review-card";
      const rating = Math.max(1, Math.min(5, Number(r.rating) || 5));
      const s = document.createElement("div"); s.className = "stars-out";
      s.setAttribute("aria-label", rating + " out of 5 stars");
      s.textContent = "★".repeat(rating) + "☆".repeat(5 - rating);
      const p = document.createElement("p"); p.textContent = r.review || r.text || "";
      const f = document.createElement("footer"), n = document.createElement("strong");
      n.textContent = r.name || "Client"; f.appendChild(n);
      if (r.role) f.append(" · " + r.role);
      c.append(s, p, f);
      if (prepend) list.prepend(c); else list.appendChild(c);
    }
    async function loadReviews() {
      try {
        const response = await fetch(SUPABASE_URL + "/rest/v1/reviews?select=id,name,role,rating,review,created_at&order=created_at.desc", {
          headers: { "apikey": SUPABASE_PUBLISHABLE_KEY, "Authorization": "Bearer " + SUPABASE_PUBLISHABLE_KEY }
        });
        if (!response.ok) throw new Error("Could not load reviews");
        const reviews = await response.json();
        list.replaceChildren();
        if (reviews.length) reviews.forEach(r => addReview(r));
        else showEmpty();
      } catch (error) {
        console.error("Reviews could not be loaded:", error);
        if (!list.children.length) showEmpty();
      }
    }
    REVIEWS.forEach(r => addReview({ ...r, review: r.text }));
    if (!list.children.length) showEmpty();
    loadReviews();

    if (rf) rf.addEventListener("submit", async e => {
      e.preventDefault();
      if (!rf.checkValidity()) { rf.reportValidity(); return; }
      const honeypot = rf.querySelector('[name="bot-field"]');
      if (honeypot && honeypot.value) return;
      const btn = rf.querySelector('button[type="submit"]');
      const data = new FormData(rf);
      const review = {
        name: String(data.get("name") || "").trim(),
        role: String(data.get("role") || "").trim(),
        rating: Number(data.get("rating")),
        review: String(data.get("review") || "").trim()
      };
      btn.disabled = true;
      status.className = "";
      status.textContent = "Sending...";
      try {
        const response = await fetch(SUPABASE_URL + "/rest/v1/reviews", {
          method: "POST",
          headers: {
            "apikey": SUPABASE_PUBLISHABLE_KEY,
            "Authorization": "Bearer " + SUPABASE_PUBLISHABLE_KEY,
            "Content-Type": "application/json",
            "Prefer": "return=representation"
          },
          body: JSON.stringify(review)
        });
        if (!response.ok) {
          const details = await response.text();
          throw new Error(details || "Review submission failed");
        }
        const saved = await response.json();
        rf.reset();
        status.className = "ok";
        status.textContent = "Thank you! Your review is now published.";
        if (saved && saved[0]) addReview(saved[0], true);
        else await loadReviews();
      } catch (error) {
        console.error("Review submission failed:", error);
        status.className = "err";
        status.textContent = "Sorry, your review could not be sent. Please try again later.";
      } finally {
        btn.disabled = false;
      }
    });
  }

  /* ----- animated counters (real numbers taken from the page itself) ----- */
  const vals = { services: $$(".svc").length + $$(".tick-set:not([aria-hidden]) .tick").length, projects: typeof PROJECTS !== "undefined" ? PROJECTS.length : 0, core: $$(".svc").length };
  const cio = new IntersectionObserver(es => es.forEach(e => {
    if (!e.isIntersecting) return; cio.unobserve(e.target);
    const to = vals[e.target.dataset.count] || 0;
    if (reduce.matches) { e.target.textContent = to; return; }
    const t0 = performance.now();
    (function tick(t) { const p = Math.min((t - t0) / 1100, 1); e.target.textContent = Math.round(to * (1 - Math.pow(1 - p, 3))); if (p < 1) requestAnimationFrame(tick); })(t0);
  }), { threshold: .6 });
  $$("[data-count]").forEach(el => { el.textContent = reduce.matches ? vals[el.dataset.count] : 0; cio.observe(el); });

  /* ----- cursor spotlight on cards ----- */
  if (matchMedia("(hover:hover)").matches) {
    document.addEventListener("pointermove", e => {
      const c = e.target.closest && e.target.closest(".card"); if (!c) return;
      const r = c.getBoundingClientRect(); c.style.setProperty("--mx", e.clientX - r.left + "px"); c.style.setProperty("--my", e.clientY - r.top + "px");
    }, { passive: true });
  }

  /* ----- scroll progress bar ----- */
  const bar = $("#progress"); let tick = false;
  const upd = () => { const h = document.documentElement; bar.style.transform = "scaleX(" + (h.scrollTop / ((h.scrollHeight - h.clientHeight) || 1)) + ")"; tick = false; };
  addEventListener("scroll", () => { if (!tick) { tick = true; requestAnimationFrame(upd); } }, { passive: true }); upd();

  /* ----- robot eyes follow the pointer ----- */
  const bot = $(".hero-bot"), pupils = bot && $(".pupils", bot), hero = $("#home");
  if (pupils && hero && !reduce.matches && matchMedia("(hover:hover)").matches) {
    hero.addEventListener("pointermove", e => {
      const r = bot.getBoundingClientRect(), dx = (e.clientX - (r.left + r.width / 2)) / r.width, dy = (e.clientY - (r.top + r.height * .35)) / r.height;
      pupils.style.transform = "translate(" + Math.max(-1, Math.min(1, dx * 2)) * 4 + "px," + Math.max(-1, Math.min(1, dy * 2)) * 3 + "px)";
    }, { passive: true });
    hero.addEventListener("pointerleave", () => { pupils.style.transform = ""; });
  }
})();
