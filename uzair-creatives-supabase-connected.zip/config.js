/* ===== SETTINGS: edit these before deploying (shared by every page) ===== */
const CONFIG = {
  whatsappNumber: "923379755960", // digits only, country code first, no + or leading 0. Pakistan example: 923001234567
  email: "uzairmirza532@gmail.com", // contact email shown on the website
  whatsappMessage: "Hello Uzair, I visited your website and would like to discuss an AI automation or AI agent project."
};

