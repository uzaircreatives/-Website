/* ===== 2. PORTFOLIO: max 6 projects, max 3 images each =====
   Put image files in assets/projects/ using the names below (or change the paths).
   Missing images show a placeholder automatically. Leave link as "" to hide the link. */
const PROJECTS = [
  {
    title: "JARVIS",
    category: "AI Multi-Agent System",
    short: "A team of 4 AI agents that research, find tenders, help with online stores, and write content, all from one dashboard.",
    problem: "Research, tender searching, store tasks and writing take a lot of time when done by hand, and one AI chatbot cannot do all of them well.",
    solution: "You send a task from the dashboard. A Bot Router reads it and passes it to the right agent. RADAR does web research, TENDER finds tenders, STORE helps with online store tasks, and SCRIBE writes content and emails. Each agent has its own AI model and tools. The answer comes back to a live dashboard where you can see tasks and results. You can also chain agents, for example: find tenders first, then write an email about them.",
    tools: ["n8n", "Gemini", "OpenRouter", "Webhooks", "Custom Dashboard"],
    images: ["assets/projects/project-1-main.webp", "assets/projects/project-1-workflow.webp", "assets/projects/project-1-result.webp"],
    link: ""
  },
  {
    title: "WhatsApp AI Customer Agent",
    category: "AI Agent",
    short: "An AI agent that answers customer messages on WhatsApp 24/7 using your product and business details.",
    problem: "Businesses get the same customer questions again and again on WhatsApp, and replying to every message quickly is hard.",
    solution: "When a customer sends a message, the workflow removes spam and empty or non-text messages. The AI agent (Gemini) reads the question, checks your product and business details, and sends a helpful reply. The conversation is saved, and the owner gets a Telegram alert when a human needs to take over or a new lead comes in.",
    tools: ["n8n", "Gemini", "WhatsApp Cloud API", "Airtable", "Telegram"],
    images: ["assets/projects/project-2-main.webp", "assets/projects/project-2-workflow.webp", "assets/projects/project-2-result.webp"],
    link: ""
  },
  {
    title: "Google Maps Lead Generation",
    category: "Lead Generation Automation",
    short: "Finds local businesses on Google Maps, collects contact details, and organizes leads in a Google Sheets tracker for follow-up.",
    problem: "Finding local businesses, searching for their contact emails and writing outreach emails by hand takes hours.",
    solution: "You enter a keyword, for example a type of business. The automation collects business names, phone numbers, websites and addresses from Google Maps. It visits each website, and Gemini AI looks for a business email. Businesses with no website or no email are skipped. Then Gemini writes and polishes a personalized outreach email, Gmail sends it, and the lead details are organized in a Google Sheets tracker for follow-up.",
    tools: ["Make.com", "Gemini", "Apify", "Gmail", "Google Sheets"],
    images: ["assets/projects/project-3-main.webp", "assets/projects/project-3-workflow.webp", "assets/projects/project-3-result.webp"],
    link: ""
  },
  {
    title: "Tender Intelligence Agent",
    category: "AI Agent / Procurement Automation",
    short: "An AI agent that reads government and private tenders, scores how well each one fits your company, and saves clear summaries to Google Sheets for review.",
    problem: "Checking tender websites again and again takes time, and it is easy to miss a good tender or spend hours on one that does not fit your business.",
    solution: "The workflow loads tenders from a source, cleans the data and adds your company profile. An AI Tender Agent (Gemini) can open each tender page with a page-reader tool and returns a structured result: relevance (high, medium or low), match reasons and key requirements. A filter then checks if it is a relevant opportunity. Relevant tenders go to a human review queue and are saved to a Google Sheet; low-relevance ones are logged separately. A person always makes the final decision. This version uses demo tender data, and a live tender source can be connected. It can run on a schedule, for example every hour.",
    tools: ["n8n", "Gemini", "Google Sheets", "Structured Output"],
    images: ["assets/projects/project-4-main.webp", "assets/projects/project-4-workflow.webp", "assets/projects/project-4-result.webp"],
    link: ""
  }  /* Add the next project here (copy one block above, put a comma after the previous "}").
     Use images project-5-main.webp, project-5-workflow.webp, project-5-result.webp (plus a -sm.webp card version, 720px wide). Max 6 projects. */
];
/* To edit one project, change its fields above. Replace the whole map() with six {…} objects if you prefer. */

/* ===== Code below: no need to edit ===== */
const $ = s => document.querySelector(s);
const ph = t => "data:image/svg+xml," + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="800" height="500"><rect width="800" height="500" fill="#1a2740"/><text x="400" y="240" text-anchor="middle" font-family="Arial" font-size="26" fill="#c9d6ee">Add your image</text><text x="400" y="280" text-anchor="middle" font-family="Arial" font-size="16" fill="#8da2c4">' + t + '</text></svg>');
const safe = (img, src) => { img.onerror = () => { img.onerror = null; img.src = ph(src); }; img.src = src; };
const el = (tag, cls, txt) => { const e = document.createElement(tag); if (cls) e.className = cls; if (txt) e.textContent = txt; return e; };

// Portfolio cards
const grid = $("#projects");
PROJECTS.slice(0, 6).forEach((p, i) => {
  const imgs = p.images.slice(0, 3);
  const c = el("article", "card proj"), img = el("img"), b = el("div", "body");
  img.alt = p.title + " - main project image"; img.loading = "eager"; img.decoding = "async"; img.width = 720; img.height = 450; safe(img, (imgs[0] || "").replace(/\.webp$/, "-sm.webp"));
  const tags = el("p", "tags"); p.tools.forEach(t => tags.append(el("span", "", t)));
  const btn = el("button", "btn btn-outline", "View Details"); btn.type = "button"; btn.onclick = () => openModal(i);
  b.append(el("p", "cat", p.category), el("h3", "", p.title), el("p", "", p.short), tags, btn);
  c.append(img, b); grid.append(c);
});

// Project gallery
const modal = $("#modal"); let cur = 0, idx = 0;
function show() {
  const p = PROJECTS[cur], imgs = p.images.slice(0, 3), m = $("#m-img");
  m.alt = p.title + " - image " + (idx + 1) + " of " + imgs.length; safe(m, imgs[idx]);
  $("#count").textContent = (idx + 1) + " / " + imgs.length;
  document.querySelectorAll(".gnav button").forEach(x => x.hidden = imgs.length < 2);
}
function openModal(i) {
  cur = i; idx = 0; const p = PROJECTS[i];
  $("#m-title").textContent = p.title; $("#m-cat").textContent = p.category;
  $("#m-problem").textContent = p.problem; $("#m-solution").textContent = p.solution;
  const t = $("#m-tools"); t.replaceChildren(); p.tools.forEach(x => t.append(el("span", "", x)));
  const l = $("#m-link"); l.hidden = !p.link; if (p.link) l.href = p.link;
  show(); modal.showModal();
}
$("#prev").onclick = () => { idx = (idx + PROJECTS[cur].images.slice(0, 3).length - 1) % PROJECTS[cur].images.slice(0, 3).length; show(); };
$("#next").onclick = () => { idx = (idx + 1) % PROJECTS[cur].images.slice(0, 3).length; show(); };
modal.querySelector(".close").onclick = () => modal.close();
modal.addEventListener("click", e => { if (e.target === modal) modal.close(); });

// "Discuss This Service" preselects the dropdown
document.querySelectorAll("[data-service]").forEach(a => a.addEventListener("click", () => { $("#service").value = a.dataset.service; }));

// WhatsApp
const num = CONFIG.whatsappNumber.replace(/\D/g, ""), waOk = /^\d{10,15}$/.test(num) && !/[A-Za-z]/.test(CONFIG.whatsappNumber);
const wa = $("#wa");
wa.href = "https://wa.me/" + (waOk ? num : "YOURWHATSAPPNUMBER") + "?text=" + encodeURIComponent(CONFIG.whatsappMessage);
if (!waOk) wa.addEventListener("click", e => { e.preventDefault(); alert("WhatsApp number not set yet. Open script.js and edit CONFIG.whatsappNumber."); });

// Email (hidden until configured)
if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(CONFIG.email)) { $("#email-link").href = "mailto:" + CONFIG.email; $("#email-link").textContent = CONFIG.email; $("#email-line").hidden = false; }

// Contact form (Netlify Forms)
const f = $("#inquiry"), st = $("#status");
f.addEventListener("submit", async e => {
  e.preventDefault();
  if (!f.checkValidity()) { f.reportValidity(); return; }
  const btn = f.querySelector("button"); btn.disabled = true; st.className = ""; st.textContent = "Sending...";
  try {
    const r = await fetch("/", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams(new FormData(f)).toString() });
    if (!r.ok) throw new Error(r.status);
    f.reset(); st.className = "ok"; st.textContent = "Thank you! Your inquiry has been sent. I will review it and reply soon.";
  } catch (err) {
    st.className = "err"; st.textContent = "Sorry, your inquiry could not be sent. Please try again, or contact me on WhatsApp.";
  }
  btn.disabled = false;
});
$("#year").textContent = new Date().getFullYear();
