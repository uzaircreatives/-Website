/* Uzair Creatives v2 - motion layer: preloader, robot world canvas, word-roll headings, roll buttons,
   tilt cards, magnetic buttons, timeline, robot simulator, theme switch. Safe to edit separately. */
(() => {
  const $ = (s, c = document) => c.querySelector(s), $$ = (s, c = document) => [...c.querySelectorAll(s)];
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches, hover = matchMedia("(hover:hover)").matches;
  const root = document.documentElement;

  /* hero headline starts straight away (no loader) */
  setTimeout(() => $$("#home [data-split]").forEach(h => h.classList.add("in")), 120);

  /* theme switch */
  const tb = $("#theme-toggle");
  if (tb) {
    const sync = () => { const d = root.dataset.theme === "dark"; tb.setAttribute("aria-pressed", d); tb.setAttribute("aria-label", d ? "Dark theme. Switch to light" : "Light theme. Switch to dark"); };
    tb.addEventListener("click", () => { root.dataset.theme = root.dataset.theme === "dark" ? "light" : "dark"; try { localStorage.setItem("uc-theme", root.dataset.theme); } catch (e) {} sync(); });
    sync();
  }

  /* headings: words roll up from a mask */
  $$("[data-split]").forEach(h => {
    let i = 0;
    const walk = n => [...n.childNodes].forEach(c => {
      if (c.nodeType === 3) {
        const f = document.createDocumentFragment();
        c.textContent.split(/(\s+)/).forEach(w => { if (!w.trim()) { f.append(w); return; } const s = document.createElement("span"), t = document.createElement("i"); s.className = "sw"; t.textContent = w; t.style.setProperty("--i", i++); s.append(t); f.append(s); });
        c.replaceWith(f);
      } else if (c.nodeType === 1) walk(c);
    });
    walk(h);
  });

  /* roll text on buttons and nav links */
  $$("[data-roll], nav a:not(.btn)").forEach(a => {
    const t = a.textContent.trim(); a.textContent = "";
    const r = document.createElement("span"); r.className = "rl";
    for (let k = 0; k < 2; k++) { const i = document.createElement("i"); i.textContent = t; if (k) i.setAttribute("aria-hidden", "true"); r.append(i); }
    a.append(r);
  });

  /* reveal on scroll */
  const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add("in"); if (!e.target.matches("[data-split]")) io.unobserve(e.target); } }), { threshold: .18, rootMargin: "0px 0px -6% 0px" });
  $$("[data-r]").forEach(el => io.observe(el));
  $$("[data-split]:not(#home *)").forEach(h => io.observe(h));
  const lateIO = new MutationObserver(() => $$("#projects .proj:not([data-r])").forEach((c, i) => { c.dataset.r = ""; c.style.setProperty("--d", i * .1 + "s"); io.observe(c); })); lateIO.observe($("#projects"), { childList: true });
  $$("#projects .proj").forEach((c, i) => { c.dataset.r = ""; c.style.setProperty("--d", i * .1 + "s"); io.observe(c); });

  /* scroll effects: header, active link, timeline (positions are cached, so a scroll frame never forces layout) */
  const links = $$("nav a[href^='#']"), secs = links.map(a => $(a.getAttribute("href"))).filter(Boolean), hdr = $(".site-header"), steps = $("#steps");
  let lastY = 0, tick = false, tops = [], sTop = 0, sH = 1, hdrHidden = false, curId = null;
  const measure = () => { const y = scrollY; tops = secs.map(s => s.getBoundingClientRect().top + y); if (steps) { const r = steps.getBoundingClientRect(); sTop = r.top + y; sH = r.height || 1; } };
  const onScroll = () => {
    const y = scrollY, vh = innerHeight; tick = false;
    const hide = y > 300 && y > lastY + 4 && innerWidth > 959; if (hide !== hdrHidden) { hdrHidden = hide; hdr.style.transform = hide ? "translateY(-120%)" : ""; } lastY = y;
    let cur = ""; for (let i = 0; i < secs.length; i++) if (tops[i] - y < vh * .4) cur = "#" + secs[i].id;
    if (cur !== curId) { curId = cur; links.forEach(a => a.classList.toggle("act", a.getAttribute("href") === cur)); }
    if (steps) steps.style.setProperty("--tl", Math.max(0, Math.min(1, (vh * .65 - (sTop - y)) / sH)).toFixed(3));
  };
  addEventListener("scroll", () => { if (!tick) { tick = true; requestAnimationFrame(onScroll); } }, { passive: true });
  addEventListener("uc:layout", () => { measure(); onScroll(); }); addEventListener("load", () => { measure(); onScroll(); }); measure(); onScroll();

  /* pointer: glow, tilt, magnetic buttons (desktop only; the glow loop sleeps when the pointer is still) */
  const cur = $("#cur");
  if (hover && !reduce && !root.classList.contains("lite")) {
    let mx = 0, my = 0, cx = 0, cy = 0, run = false;
    const loop = () => { cx += (mx - cx) * .16; cy += (my - cy) * .16; cur.style.transform = "translate3d(" + cx.toFixed(1) + "px," + cy.toFixed(1) + "px,0)"; if (Math.abs(mx - cx) + Math.abs(my - cy) > .5) requestAnimationFrame(loop); else run = false; };
    addEventListener("pointermove", e => {
      mx = e.clientX; my = e.clientY; if (!run) { run = true; requestAnimationFrame(loop); }
      const t = e.target.closest && e.target.closest("[data-tilt]");
      if (t) { const r = t.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5; t.style.transform = "perspective(900px) rotateY(" + x * 7 + "deg) rotateX(" + -y * 7 + "deg) translateY(-3px)"; }
    }, { passive: true });
    $$("[data-tilt]").forEach(t => t.addEventListener("pointerleave", () => { t.style.transform = ""; }));
    $$(".btn-primary, .wa").forEach(b => { b.addEventListener("pointermove", e => { const r = b.getBoundingClientRect(); b.style.transform = "translate(" + (e.clientX - r.left - r.width / 2) * .18 + "px," + (e.clientY - r.top - r.height / 2) * .25 + "px)"; }); b.addEventListener("pointerleave", () => { b.style.transform = ""; }); });
  } else if (cur) cur.remove();

  /* robot world: light network canvas. Fewer points on weak devices, squared distances, paused when hidden */
  const cv = $("#hero-canvas");
  if (cv && !reduce) {
    const lite = root.classList.contains("lite"), g = cv.getContext("2d", { alpha: true });
    let w, h, pts = [], on = true, px = -999, py = -999, last = 0, raf = 0;
    const LINK = lite ? 100 : 125, L2 = LINK * LINK, gap = lite ? 33 : 0;
    const size = () => { const d = lite ? 1 : Math.min(devicePixelRatio || 1, 1.5); w = cv.clientWidth; h = cv.clientHeight; cv.width = w * d; cv.height = h * d; g.setTransform(d, 0, 0, d, 0, 0); const n = lite ? 22 : Math.round(Math.min(48, w * h / 22000)); pts = Array.from({ length: n }, () => ({ x: Math.random() * w, y: Math.random() * h, vx: (Math.random() - .5) * .3, vy: (Math.random() - .5) * .3, r: Math.random() * 1.4 + .7 })); };
    size(); let rz; addEventListener("resize", () => { clearTimeout(rz); rz = setTimeout(size, 200); });
    if (!lite) cv.parentElement.addEventListener("pointermove", e => { const r = cv.getBoundingClientRect(); px = e.clientX - r.left; py = e.clientY - r.top; }, { passive: true });
    const start = () => { if (!raf && on) raf = requestAnimationFrame(draw); };
    new IntersectionObserver(es => { on = es[0].isIntersecting; if (on) start(); }).observe(cv);
    document.addEventListener("visibilitychange", () => { on = !document.hidden; if (on) start(); });
    function draw(t) {
      raf = 0; if (!on || root.classList.contains("hero-away")) { return; }
      if (gap && t - last < gap) { raf = requestAnimationFrame(draw); return; } last = t;
      g.clearRect(0, 0, w, h);
      const light = root.dataset.theme === "light", rgb = light ? "47,128,255" : "140,215,255";
      g.fillStyle = "rgba(" + rgb + ",.75)";
      for (let i = 0; i < pts.length; i++) {
        const p = pts[i], dx = p.x - px, dy = p.y - py, d2 = dx * dx + dy * dy; if (d2 < 14400 && d2 > 1) { const d = Math.sqrt(d2); p.x += dx / d * 1.3; p.y += dy / d * 1.3; }
        p.x += p.vx; p.y += p.vy; if (p.x < 0 || p.x > w) p.vx *= -1; if (p.y < 0 || p.y > h) p.vy *= -1;
        g.beginPath(); g.arc(p.x, p.y, p.r, 0, 6.283); g.fill();
        for (let j = i + 1; j < pts.length; j++) { const q = pts[j], ax = p.x - q.x, ay = p.y - q.y, l2 = ax * ax + ay * ay; if (l2 < L2) { g.strokeStyle = "rgba(" + rgb + "," + ((1 - l2 / L2) * .32).toFixed(2) + ")"; g.beginPath(); g.moveTo(p.x, p.y); g.lineTo(q.x, q.y); g.stroke(); } }
      }
      raf = requestAnimationFrame(draw);
    }
    addEventListener("uc:resume", start); start();
  }

  /* robot simulator */
  const log = $("#log"), nodes = $$(".node"), pk = $(".packet"), run = $("#run");
  if (log) {
    const S = [
      { n: ["Form", "AI Agent", "Google Sheets", "WhatsApp"], l: ["Form received: new project inquiry", "AI Agent reads the message and scores the lead", "Lead saved to your Google Sheet", "You get an instant alert on WhatsApp"] },
      { n: ["Message", "AI Agent", "Your data", "Reply"], l: ["Customer message arrives on WhatsApp", "AI Agent understands the question", "Agent checks your product and price details", "Helpful reply sent in seconds, any time of day"] },
      { n: ["Gmail", "AI Reader", "Spreadsheet", "Alert"], l: ["Invoice email detected in Gmail", "AI reads supplier, amount and due date", "Details added to your spreadsheet", "Reminder sent before the due date"] }
    ];
    let cur = 0, timers = [];
    const play = () => {
      timers.forEach(clearTimeout); timers = []; log.textContent = ""; nodes.forEach(n => n.classList.remove("on")); pk.style.opacity = 0;
      S[cur].n.forEach((t, i) => { nodes[i].lastChild.textContent = t; });
      S[cur].l.forEach((t, i) => timers.push(setTimeout(() => {
        nodes[i].classList.add("on"); pk.style.opacity = 1; pk.style.left = (12.5 + i * 25) + "%";
        log.textContent += (i ? "\n" : "") + "[robot " + (i + 1) + "] " + t;
      }, reduce ? 0 : 500 + i * 900)));
      timers.push(setTimeout(() => { log.textContent += "\n✓ Done. No manual work needed."; pk.style.opacity = 0; }, reduce ? 0 : 500 + 4 * 900));
    };
    $$(".scn button").forEach(b => b.addEventListener("click", () => { cur = +b.dataset.s; $$(".scn button").forEach(x => x.setAttribute("aria-pressed", x === b)); play(); }));
    run.addEventListener("click", play);
    new IntersectionObserver((es, o) => { if (es[0].isIntersecting) { play(); o.disconnect(); } }, { threshold: .5 }).observe($(".lab"));
  }
})();

