# Uzair Creatives Website v2 - "AI robot world" (static, Netlify-ready)

## What changed in v2
- New design: index.html + modern.css + fx.js (motion). Same navy / cyan / blue / violet colours.
- Hero: humanoid robot, 4 working mini-robots, live particle network, headline that rolls in, preloader.
- New: "Watch a robot team handle a task" live demo (3 scenarios), scroll-drawn process timeline, roll-text buttons, tilt cards, magnetic buttons, cursor glow, swipeable project cards, dark/light switch.
- Blog page uses the same new design. Old styles.css / enhance.css / enhance.js are no longer used (safe to delete).
- Unchanged logic: config.js, script.js (PROJECTS), sections.js (booking, reviews, webhook), tabs.js, nav.js, all Netlify form names.

## v2.1 additions
- 3 human-like android robots in the hero, glass-blue "water" look, classic serif headings (Playfair Display), no loader on open.
- New sections: "How I Work" (integrations, API keys, revisions, JSON delivery) and "Terms of Service" (50% advance, demo, balance, handover after full payment). Edit the wording directly in index.html (ids: method, terms).
- FAQ now includes "How much does a project cost?".

## Your own robot image
Save it as assets/hero/robot.png, then in index.html replace the whole <svg class="robot"> ... </svg> with:
<img class="robot-img" src="assets/hero/robot.png" alt="">


## Files
- index.html - main page (services, portfolio, about, FAQ, contact with Inquiry + Book a Slot tabs)
- blog.html / blog.js - Blog sub page (opens from About > Blog in the menu)
- config.js - SETTINGS (WhatsApp, email) shared by all pages
- nav.js / tabs.js - menu dropdowns and the contact tabs
- styles.css - base styling; theme colours at the top (:root = light, [data-theme="dark"] = dark)
- enhance.css / enhance.js - animations, hero network background, service visuals, theme switcher (safe to edit separately; script.js is untouched apart from placeholder image colours)
- script.js - PORTFOLIO (6 projects) at the top
- assets/logo/ - your logo (logo.png = small header version, logo-original.png = untouched original)
- assets/projects/ - your project screenshots

## Before publishing (3 things)
1. WhatsApp is configured to +92 337 9755960 (stored as 923379755960 in config.js). The website button opens a WhatsApp chat with a pre-filled message.
2. Contact email is set to uzairmirza532@gmail.com in config.js. This shows the email link on the website; it does not by itself configure Netlify email notifications.
3. Portfolio: edit the PROJECTS list in script.js. Save images in assets/projects/ as project-1-main.jpg, project-1-workflow.jpg, project-1-result.jpg (up to 3 per project, 6 projects). Use JPG/WebP under ~300 KB each. Missing images show a placeholder.

## Deploy on Netlify (free)
1. Go to app.netlify.com and sign up/log in (this is for you only; visitors never log in).
2. Add new site -> Deploy manually -> drag the whole unzipped uzair-creatives FOLDER into the box.
3. Netlify gives you a link like https://random-name.netlify.app. Rename it in Site configuration -> Change site name.
4. Form: open Site -> Forms. The form "project-inquiry" should be detected after deploy. If not, go to Forms -> Enable form detection, then redeploy.
5. Email alerts: in Netlify -> Forms -> Submission notifications, add an email notification addressed to uzairmirza532@gmail.com for project-inquiry and (if desired) slot-booking/client-review. The email address in config.js only shows the contact link; it does not create these dashboard notifications. No auto-reply automation is configured.
6. Reviews: submissions appear under Netlify -> Forms -> client-review and are NOT published automatically. Approve a real review by adding it to the REVIEWS list in sections.js and redeploying. To hide/remove it from the site, remove it from that list. Netlify Forms itself does not provide a one-click approval queue for public display.
7. Test: submit a review on the live site and check Forms -> client-review -> Submissions. Use a clearly labelled test review and do not publish it. Netlify's free plan has a monthly submission limit.
6. Test the WhatsApp button on your phone.

## Updating later
Edit the files, then in Netlify go to Deploys and drag the folder again (or connect a GitHub repo for automatic updates).
Note: the form only works on the live Netlify site, not when opening index.html from your computer.

\n## WhatsApp greeting note
The website can open a WhatsApp chat and pre-fill a message, but it cannot automatically send a welcome reply from your number after a visitor messages you. For that, configure the Greeting Message feature in the WhatsApp Business app, or connect WhatsApp Business Platform/API with an approved automation workflow. Test the number and greeting on your own phone before publishing.


## v3 additions
- Hero is now a pinned scroll scene: scroll and the humanoid robots move, the text fades out and each robot is highlighted with a caption.
- scrollfx.js + scrollfx.css (+ lenis.min.js): smooth scrolling, 3D card entrances in every section, pinned horizontal Projects with a curved card arc, background colour shift per section, floating glass shapes.
- Remove the effects any time by deleting the scrollfx.css / lenis.min.js / scrollfx.js lines at the bottom of index.html (hero height then needs .hero{height:auto}).

## v6 - photo background
- `bg-room-1920.webp` / `bg-room-960.webp` (phones) are fixed behind the whole site. A "camera" (scrollfx.js, WP array) pans/zooms across the photo as you scroll.
- Idle motion is CSS only: slow drift, globe rings, scan line, pulses, rising dots. Change the picture by replacing the two webp files (keep 16:9) and tuning the effect positions in scrollfx.css (.gl-*, .orb, .scan, .sweep, .eye are % of the image).
- Phones / weak devices get the `lite` mode: smaller image, fewer effects.

## v7
- New project: Tender Intelligence Agent (script.js). Card images are `-sm.webp` (720px), modal images are full webp.
- Fog layers: fog-a/b.webp (+ -sm for phones). Card textures: assets/tex/card-1..6.webp, set with --tex in scrollfx.css.
- Terms of Service animations only run while that section is on screen (#terms.live).

## v8
- smooth.css / smooth.js: transparent cards, inertia wheel scrolling (desktop), cursor spotlight on all cards, lighter GPU load.
- bg-room-2880.webp is an upscaled copy of the 1920 photo; swap in a real 2880px+ original (same name) for true sharpness.
- Projects: cards now only move (translate) and fade, one after another. Camera zoom lowered for a sharper background.

## v9
- Mouse depth parallax (photo/fog/dust layers), dust stretches with scroll speed, section colour mood, hover gradient border on cards, hero text order + fade-out on scroll, smooth FAQ open, Home<->Blog page transition (page.css).
